from math import *
a=float(input("斜边1的长度："))
b=float(input("斜边2的长度："))
c=a*a+b*b
c=sqrt(c)
print("斜边长为：",c)